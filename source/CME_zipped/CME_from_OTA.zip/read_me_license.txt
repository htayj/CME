The texts in this folder 'CME_from_OTA' (or in the zipped-up version of that folder) are derived ultimately -- though often with considerable improvements and remediation -- from files
distributed by the Oxford Text Archive. As of February 2019, OTA
distributes these files under a CC 'sharealike' license, viz.,

https://creativecommons.org/licenses/by-nc-sa/3.0/

In keeping with the terms of that license, we distribute
them under the same license, and herein acknowledge
their OTA origins.

